# FunkGateway Mumble Bridge 0.1.1

Die Bridge ist für Mumble-Server gedacht, auf denen mehrere Gatewaybetreiber
arbeiten, die **nicht** das globale Murmur-Ice-Write-Secret erhalten sollen.

## Sicherheitsmodell

Der Gatewaybetreiber erhält nur ein individuelles Bridge-Token.

Das Token ist serverseitig fest gebunden an:

- genau einen Mumble-Benutzernamen,
- genau einen Normalraum,
- genau einen Störungsraum.

Die Bridge akzeptiert absichtlich **keine** freie Benutzer-ID und **keine**
beliebige Channel-ID aus dem Client.

Erlaubte Schreibaktionen in 0.1.1:

1. Normalraum -> freigegebener Störungsraum
2. Störungsraum -> freigegebener Normalraum

Das echte `icesecretwrite` bleibt ausschließlich auf dem Server.

## API

- `GET /api/v1/status`
- `GET /api/v1/gateway`
- `POST /api/v1/gateway/disturbance`
- `POST /api/v1/gateway/return`

Authentifizierung:

`Authorization: Bearer <persoenliches Gateway-Token>`

## Installation

Siehe `docs/ADMIN-INSTALLATION.md`.

## Wichtige Grenze

Die Bridge ersetzt nicht die Mumble-/Murmur-Administration. Sie reduziert nur
die Rechte, die ein FunkGateway-Client über eine kleine API nutzen kann.

Ein gestohlenes Gateway-Token erlaubt maximal die für dieses Token
freigegebenen Gateway-Aktionen. Es gibt keinen Zugriff auf das eigentliche
Ice-Secret.


## Betriebsarten in FunkGateway

**Normaler Gatewaybetreiber:** verwendet die Bridge des Server-Admins und
bekommt ausschließlich Bridge-Adresse + persönliches Token.

**Server-Admin/eigener Server:** kann FunkGateway alternativ direkt mit Ice
oder Ice über SSH verwenden. Eine Bridge ist dann optional.

Eine Bridge auf dem Rechner eines normalen Gatewaybetreibers schützt das
Ice-Secret nicht, wenn der Betreiber den Rechner selbst administriert.
