# API 0.1

Alle Gateway-Endpunkte außer `/api/v1/status` benötigen:

```text
Authorization: Bearer fgw_...
```

## GET /api/v1/status

Bridge-/Ice-Status. Keine Schreibaktion.

## GET /api/v1/gateway

Liefert nur den dem Token zugeordneten Gateway-Benutzer und dessen aktuellen
Channel.

## POST /api/v1/gateway/disturbance

Erlaubt ausschließlich:

```text
konfigurierter Normalraum -> konfigurierter Störungsraum
```

## POST /api/v1/gateway/return

Erlaubt ausschließlich:

```text
konfigurierter Störungsraum -> konfigurierter Normalraum
```

Der Client kann keine freie Channel-ID mitsenden.
