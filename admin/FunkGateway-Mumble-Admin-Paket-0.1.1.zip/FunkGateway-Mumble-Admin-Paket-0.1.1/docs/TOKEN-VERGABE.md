# Token-Vergabe

Für jeden FunkGateway-Betreiber wird ein eigenes Token erzeugt.

Beispiel:

```sh
sudo fgw-bridge-admin add \
  --label "Gateway Musterstadt" \
  --user "GW Musterstadt" \
  --normal 9 \
  --disturbance 62
```

Der Admin übergibt nur das ausgegebene `fgw_...`-Token und die öffentliche
HTTPS-Adresse der Bridge an den Gatewaybetreiber.

Nie weitergeben:

- `icesecretread`
- `icesecretwrite`
- SSH-Zugang des Server-Admins
- Server-Pepper

Bei Verlust:

```sh
sudo fgw-bridge-admin revoke ID
sudo fgw-bridge-admin rotate ID
```
