# Reverse-Proxy

Die Bridge bindet standardmäßig an `127.0.0.1:8787`.

Für externe FunkGateway-Clients soll ein HTTPS-Reverse-Proxy verwendet werden.

## Beispiel Nginx

```nginx
server {
    listen 443 ssl;
    server_name bridge.example.org;

    ssl_certificate     /etc/letsencrypt/live/bridge.example.org/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/bridge.example.org/privkey.pem;

    location /api/ {
        proxy_pass http://127.0.0.1:8787;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_set_header X-Forwarded-Proto https;
        client_max_body_size 16k;
    }
}
```

Firewall-seitig muss Port 8787 nicht extern geöffnet werden.
