# Sicherheit

## Bedrohungsmodell

Das globale Murmur-Ice-Write-Secret ist hochprivilegiert. Ein normaler
Gatewaybetreiber soll es nicht erhalten.

Die Bridge reduziert die nutzbare Oberfläche auf zwei vorgegebene
Channel-Übergänge für einen fest konfigurierten Gateway-Benutzer.

## Regeln

- Ice nach Möglichkeit nur an `127.0.0.1` binden.
- Read- und Write-Secret getrennt verwenden.
- Secrets niemals im FunkGateway-Client speichern.
- Secrets niemals in Logs schreiben.
- Pro Gateway ein eigenes Token.
- Token bei Verdacht sofort widerrufen/rotieren.
- API nur über HTTPS bereitstellen.
- Bridge als unprivilegierter Linux-Benutzer ausführen.
- Bridge-Konfigurations- und Secret-Dateien restriktiv berechtigen.
- Keine freien `session`, `user` oder `channel` Parameter in der öffentlichen API.

## Token-Speicherung

Die Datenbank speichert nicht das Bearer-Token selbst, sondern einen
HMAC-SHA256-Wert mit einem separaten serverseitigen Pepper.

Das schützt davor, dass eine reine Datenbankkopie unmittelbar gültige
Bearer-Tokens offenlegt.

## Grenzen

Wer Root-Zugriff auf den Mumble-Server hat, kann natürlich auch Bridge-Secrets
oder Murmur-Konfiguration lesen. Die Bridge schützt Gatewaybetreiber
gegeneinander und hält Ice-Admin-Credentials aus den Clients heraus; sie ist
kein Schutz gegen einen kompromittierten Server-Root.


## Bridge nicht auf einem untrusted Gateway-Rechner

Wenn ein normaler Gatewaybetreiber Root-/Benutzerkontrolle über seinen
Funkrechner hat, kann dort kein dauerhaft hinterlegtes globales Ice-Secret
wirksam vor ihm verborgen werden. Deshalb darf eine Bridge, die
`icesecretwrite` kennt, nur auf einem vom Mumble-Server-Admin kontrollierten
Server oder Management-Rechner laufen.

Für normale Gatewaybetreiber ist ausschließlich das eingeschränkte
`fgw_...`-Token vorgesehen.
