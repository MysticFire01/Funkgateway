# Admin-Installation

Diese Datei kann ein Gatewaybetreiber seinem Mumble-Server-Admin geben.

## Ziel

FunkGateway benötigt für reine lokale Mumble-Funktionen keine Serveränderung.
Für automatischen Störungsraum und Channel-Wechsel gibt es zwei Möglichkeiten:

1. **Direktes Ice** - nur für Admins/eigene Server.
2. **FunkGateway Bridge** - empfohlen für normale Gatewaybetreiber.

Bei der Bridge erhält der Gatewaybetreiber niemals das Murmur-Ice-Secret.

## 1. Bestand prüfen

```sh
cat /etc/debian_version 2>/dev/null || cat /etc/os-release
ps aux | grep -E '[m]urmur|[m]umble'
python3 --version
python3 -c 'import Ice; print(Ice.stringVersion())'
```

## 2. Murmur Ice

Ice sollte nach Möglichkeit nur lokal lauschen:

```ini
ice="tcp -h 127.0.0.1 -p 4000"
icesecretread=EIN_EIGENES_STARKES_READ_SECRET
icesecretwrite=EIN_ANDERES_STARKES_WRITE_SECRET
```

Den Ice-Port nicht ungeschützt ins Internet freigeben.

## 3. Passende Murmur.ice

Die Slice-Datei muss zur verwendeten Mumble/Murmur-Generation passen.

Bei älteren Servern wie 1.3.x heißt sie typischerweise `Murmur.ice`.
Nicht blind eine Datei einer neueren Servergeneration verwenden.

Die passende Datei nach:

```text
/opt/funkgateway-bridge/Murmur.ice
```

kopieren.

## 4. Bridge installieren

```sh
sudo ./install.sh
```

Danach Secrets in die getrennten Dateien eintragen:

```sh
sudoedit /etc/funkgateway-bridge/icesecretread
sudoedit /etc/funkgateway-bridge/icesecretwrite
```

Dateien enthalten jeweils nur das Secret, keine `key=value`-Syntax.

Konfiguration prüfen:

```sh
sudoedit /etc/funkgateway-bridge/bridge.ini
```

Starten:

```sh
sudo systemctl enable --now funkgateway-bridge
sudo systemctl status funkgateway-bridge
```

## 5. Token für einen Gatewaybetreiber

Beispiel:

```sh
sudo /usr/local/sbin/fgw-bridge-admin add \
  --label "CB 71 Kitzingen" \
  --user "001 DL BAY KT Ch71" \
  --normal 9 \
  --disturbance 62
```

Das vollständige Token wird nur bei Erstellung angezeigt.

Liste:

```sh
sudo /usr/local/sbin/fgw-bridge-admin list
```

Token sperren:

```sh
sudo /usr/local/sbin/fgw-bridge-admin revoke 1
```

Neues Token:

```sh
sudo /usr/local/sbin/fgw-bridge-admin rotate 1
```

Audit:

```sh
sudo /usr/local/sbin/fgw-bridge-admin audit --limit 100
```

## 6. Netzwerk

Standardmäßig lauscht die Bridge nur auf:

```text
127.0.0.1:8787
```

Das ist Absicht.

Für externe Gatewaybetreiber sollte ein vorhandener HTTPS-Reverse-Proxy
(Nginx, Apache, Caddy etc.) davor gesetzt werden.

Der Reverse-Proxy darf nur HTTPS veröffentlichen und leitet intern auf
`127.0.0.1:8787` weiter.

## 7. Was ein Gateway-Token NICHT darf

Ein Token kann nicht:

- beliebige Mumble-User auswählen,
- beliebige Channel-IDs angeben,
- Channels erstellen/löschen,
- ACLs ändern,
- Server starten/stoppen,
- andere virtuelle Server konfigurieren,
- das Ice-Secret lesen.

Die Bridge selbst benötigt das Ice-Write-Secret, aber der FunkGateway-Client
bekommt es niemals.
