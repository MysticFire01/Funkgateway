# Kompatibilität

## Mumble/Murmur

Die Bridge lädt eine vom Admin bereitgestellte Slice-Datei und ist deshalb
nicht fest auf eine einzige Mumble-Version verdrahtet.

Getestete Entwicklungsbasis des Projekts:

- Murmur 1.3.4
- Ice Endpoint auf localhost
- passendes `Murmur.ice`
- Python-Ice 3.7.x auf einem Testclient

Bei anderen Versionen:

1. passende Slice-Datei verwenden,
2. Read-Test durchführen,
3. Channel-Wechsel mit einem Testgateway prüfen,
4. erst dann Produktivtoken ausgeben.

## Debian 9 / ältere Systeme

Der Installer verändert absichtlich keine EOL-APT-Quellen automatisch.
Falls `python3-zeroc-ice` in den vorhandenen Repositories nicht verfügbar ist,
muss der Admin eine zur Distribution passende Ice-Python-Laufzeit bereitstellen
oder die Bridge auf einem moderneren Management-Host betreiben, der den lokalen
Ice-Endpunkt sicher erreicht.


## Empfohlener Fallback bei alten Servern

Wenn auf einem alten Mumble-Server Python-Ice wegen Paketabhängigkeiten nicht
sauber installierbar ist, den produktiven Server nicht durch erzwungene
Library-/Repository-Änderungen gefährden. Stattdessen:

1. Murmur Ice weiterhin nur lokal bereitstellen.
2. Einen modernen, vom Admin kontrollierten Linux-Host verwenden.
3. Ice per SSH-Tunnel oder privatem VPN zum Management-Host weiterleiten.
4. Dort die FunkGateway Bridge betreiben.
5. Nur die HTTPS-Bridge für Gatewaybetreiber freigeben.
