#!/bin/sh
set -eu

echo "FunkGateway Mumble Bridge - Installer"
echo

if [ "$(id -u)" -ne 0 ]; then
    echo "Bitte als root ausführen: sudo ./install.sh"
    exit 1
fi

command -v python3 >/dev/null 2>&1 || {
    echo "Python 3 fehlt. Installiere python3 ..."
    apt-get update
    apt-get install -y python3
}

if ! python3 -c 'import Ice' >/dev/null 2>&1; then
    echo "Python-Ice fehlt."
    echo "Versuche Debian/Ubuntu-Pakete zu installieren ..."
    apt-get update
    if ! apt-get install -y python3-zeroc-ice zeroc-ice-slice; then
        echo
        echo "Automatische Ice-Installation fehlgeschlagen."
        echo "Bei alten/EOL-Distributionen können Paketquellen fehlen."
        echo "Die vorhandenen APT-Quellen werden absichtlich NICHT automatisch verändert."
        echo "Bitte eine zur Distribution passende ZeroC-Ice-Python-Laufzeit installieren."
        exit 1
    fi
fi

getent group funkgateway-bridge >/dev/null 2>&1 || groupadd --system funkgateway-bridge
id funkgateway-bridge >/dev/null 2>&1 || \
    useradd --system --gid funkgateway-bridge --home /nonexistent --shell /usr/sbin/nologin funkgateway-bridge

install -d -m 0750 -o root -g funkgateway-bridge /etc/funkgateway-bridge
install -d -m 0750 -o funkgateway-bridge -g funkgateway-bridge /var/lib/funkgateway-bridge
install -d -m 0750 -o funkgateway-bridge -g funkgateway-bridge /var/log/funkgateway-bridge
install -d -m 0755 -o root -g root /opt/funkgateway-bridge

install -m 0755 fgw_bridge.py /opt/funkgateway-bridge/fgw_bridge.py
install -m 0755 fgw_bridge_admin.py /opt/funkgateway-bridge/fgw_bridge_admin.py

if [ ! -f /etc/funkgateway-bridge/bridge.ini ]; then
    install -m 0640 -o root -g funkgateway-bridge bridge.ini.example /etc/funkgateway-bridge/bridge.ini
fi

if [ ! -f /etc/funkgateway-bridge/pepper ]; then
    python3 - <<'PY' > /etc/funkgateway-bridge/pepper
import base64, os
print(base64.urlsafe_b64encode(os.urandom(48)).decode("ascii").rstrip("="))
PY
    chown root:funkgateway-bridge /etc/funkgateway-bridge/pepper
    chmod 0640 /etc/funkgateway-bridge/pepper
fi

for f in icesecretread icesecretwrite; do
    if [ ! -f "/etc/funkgateway-bridge/$f" ]; then
        : > "/etc/funkgateway-bridge/$f"
        chown root:funkgateway-bridge "/etc/funkgateway-bridge/$f"
        chmod 0640 "/etc/funkgateway-bridge/$f"
    fi
done

install -m 0644 systemd/funkgateway-bridge.service /etc/systemd/system/funkgateway-bridge.service
systemctl daemon-reload

echo
echo "Installation abgeschlossen."
echo
echo "Nächste Schritte:"
echo "  1. Passende Murmur.ice nach /opt/funkgateway-bridge/Murmur.ice kopieren"
echo "  2. /etc/funkgateway-bridge/icesecretread füllen"
echo "  3. /etc/funkgateway-bridge/icesecretwrite füllen"
echo "  4. /etc/funkgateway-bridge/bridge.ini prüfen"
echo "  5. systemctl enable --now funkgateway-bridge"
echo "  6. Gateway-Token mit fgw-bridge-admin erzeugen"
echo
echo "WICHTIG: Die Bridge lauscht standardmäßig nur auf 127.0.0.1:8787."
echo "Für externe Nutzer bitte über HTTPS-Reverse-Proxy veröffentlichen."

install -m 0755 examples/fgw-bridge-admin /usr/local/sbin/fgw-bridge-admin
