#!/bin/sh
set -u

echo "FunkGateway Mumble Bridge - Diagnose"
echo "===================================="
echo

echo "[System]"
if [ -f /etc/os-release ]; then
    . /etc/os-release
    echo "OS: ${PRETTY_NAME:-unbekannt}"
elif [ -f /etc/debian_version ]; then
    echo "Debian: $(cat /etc/debian_version)"
fi
echo "Kernel: $(uname -sr 2>/dev/null || true)"
echo

echo "[Python]"
if command -v python3 >/dev/null 2>&1; then
    python3 --version 2>&1
    if python3 -c 'import Ice; print("Python-Ice:", Ice.stringVersion())' 2>/dev/null; then
        :
    else
        echo "Python-Ice: NICHT verfügbar"
    fi
else
    echo "Python 3: NICHT verfügbar"
fi
echo

echo "[Pakete]"
if command -v apt-cache >/dev/null 2>&1; then
    apt-cache policy python3-zeroc-ice zeroc-ice-slice 2>/dev/null | sed -n '1,30p'
fi
echo

echo "[Mumble/Murmur Prozesse]"
ps aux 2>/dev/null | grep -E '[m]urmur|[m]umble' || echo "Kein Prozess erkannt"
echo

echo "[Ice Listener]"
if command -v ss >/dev/null 2>&1; then
    ss -ltnp 2>/dev/null | grep -E ':(4000|6502)[[:space:]]' || echo "Kein Listener auf typischen Ports 4000/6502 erkannt"
elif command -v netstat >/dev/null 2>&1; then
    netstat -ltnp 2>/dev/null | grep -E ':(4000|6502)[[:space:]]' || echo "Kein Listener auf typischen Ports 4000/6502 erkannt"
fi
echo

echo "[Murmur.ice]"
find "$HOME" /opt /usr/share -maxdepth 5 -type f \( -name 'Murmur.ice' -o -name 'MumbleServer.ice' \) 2>/dev/null | head -20
echo

echo "Hinweis:"
echo "Bei alten/EOL-Systemen bitte KEINE Paketabhängigkeiten mit Gewalt reparieren."
echo "Wenn Python-Ice nicht sauber installierbar ist, die Bridge auf einem"
echo "modernen, vom Admin kontrollierten Management-Rechner betreiben."
