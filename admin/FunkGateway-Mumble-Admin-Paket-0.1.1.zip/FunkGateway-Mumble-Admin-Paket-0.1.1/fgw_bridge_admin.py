#!/usr/bin/env python3
from __future__ import print_function

import argparse
import base64
import hashlib
import hmac
import json
import os
import sqlite3
import sys
import time

try:
    import configparser
except ImportError:
    import ConfigParser as configparser

def load_config(path):
    cp = configparser.ConfigParser()
    if not cp.read(path):
        raise RuntimeError("Konfiguration nicht gefunden: %s" % path)
    return {
        "database": cp.get("bridge", "database"),
        "pepper_file": cp.get("bridge", "pepper_file"),
    }

def read(path):
    with open(path, "r") as f:
        return f.read().strip()

def thash(token, pepper):
    return hmac.new(pepper.encode("utf-8"), token.encode("utf-8"), hashlib.sha256).hexdigest()

def make_token():
    raw = base64.urlsafe_b64encode(os.urandom(32)).decode("ascii").rstrip("=")
    return "fgw_" + raw

def connect(path):
    return sqlite3.connect(path)

def cmd_add(db, pepper, args):
    token = make_token()
    h = thash(token, pepper)
    cur = db.execute(
        "INSERT INTO gateways(label,mumble_user,normal_channel,disturbance_channel,token_hash,enabled,created_at) "
        "VALUES (?,?,?,?,?,1,?)",
        (args.label, args.user, args.normal, args.disturbance, h, int(time.time()))
    )
    db.commit()
    print("Gateway-ID:", cur.lastrowid)
    print("Label:", args.label)
    print("Mumble-User:", args.user)
    print("Normalraum:", args.normal)
    print("Störungsraum:", args.disturbance)
    print("")
    print("TOKEN - NUR JETZT VOLLSTÄNDIG ANGEZEIGT:")
    print(token)
    print("")
    print("Dieses Token sicher an genau diesen Gatewaybetreiber übergeben.")

def cmd_list(db, args):
    for row in db.execute(
        "SELECT id,label,mumble_user,normal_channel,disturbance_channel,enabled,created_at "
        "FROM gateways ORDER BY id"
    ):
        print("ID=%s enabled=%s label=%s user=%s normal=%s disturbance=%s" %
              (row[0], row[5], row[1], row[2], row[3], row[4]))

def cmd_revoke(db, args):
    db.execute("UPDATE gateways SET enabled=0 WHERE id=?", (args.id,))
    db.commit()
    print("Gateway/Token-ID %d wurde gesperrt." % args.id)

def cmd_enable(db, args):
    db.execute("UPDATE gateways SET enabled=1 WHERE id=?", (args.id,))
    db.commit()
    print("Gateway/Token-ID %d wurde aktiviert." % args.id)

def cmd_rotate(db, pepper, args):
    token = make_token()
    h = thash(token, pepper)
    db.execute("UPDATE gateways SET token_hash=?, enabled=1 WHERE id=?", (h, args.id))
    db.commit()
    print("Neues Token - NUR JETZT VOLLSTÄNDIG ANGEZEIGT:")
    print(token)

def cmd_audit(db, args):
    rows = db.execute(
        "SELECT datetime(ts,'unixepoch'),gateway_id,remote,action,result,detail "
        "FROM audit ORDER BY id DESC LIMIT ?",
        (args.limit,)
    ).fetchall()
    for r in reversed(rows):
        print("%s gateway=%s remote=%s action=%s result=%s detail=%s" % r)

def main():
    ap = argparse.ArgumentParser(description="FunkGateway Bridge Admin")
    ap.add_argument("--config", default="/etc/funkgateway-bridge/bridge.ini")
    sub = ap.add_subparsers(dest="cmd")

    p = sub.add_parser("add")
    p.add_argument("--label", required=True)
    p.add_argument("--user", required=True)
    p.add_argument("--normal", type=int, required=True)
    p.add_argument("--disturbance", type=int, required=True)

    sub.add_parser("list")

    p = sub.add_parser("revoke")
    p.add_argument("id", type=int)

    p = sub.add_parser("enable")
    p.add_argument("id", type=int)

    p = sub.add_parser("rotate")
    p.add_argument("id", type=int)

    p = sub.add_parser("audit")
    p.add_argument("--limit", type=int, default=50)

    args = ap.parse_args()
    if not args.cmd:
        ap.print_help()
        return 2

    cfg = load_config(args.config)
    pepper = read(cfg["pepper_file"])
    db = connect(cfg["database"])

    if args.cmd == "add":
        cmd_add(db, pepper, args)
    elif args.cmd == "list":
        cmd_list(db, args)
    elif args.cmd == "revoke":
        cmd_revoke(db, args)
    elif args.cmd == "enable":
        cmd_enable(db, args)
    elif args.cmd == "rotate":
        cmd_rotate(db, pepper, args)
    elif args.cmd == "audit":
        cmd_audit(db, args)
    return 0

if __name__ == "__main__":
    sys.exit(main())
