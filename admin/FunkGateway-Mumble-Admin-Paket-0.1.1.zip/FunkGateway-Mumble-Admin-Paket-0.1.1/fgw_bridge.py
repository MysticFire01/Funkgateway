#!/usr/bin/env python3
# FunkGateway Mumble Bridge 0.1.1
# Compatible goal: Python 3.5+ and Mumble/Murmur Ice APIs including 1.3.x.
#
# The bridge deliberately exposes only a tiny API:
#   GET  /api/v1/status
#   GET  /api/v1/gateway
#   POST /api/v1/gateway/disturbance
#   POST /api/v1/gateway/return
#
# A client token is bound server-side to exactly one configured Mumble user
# and exactly two channels (normal + disturbance). The client never receives
# the Murmur Ice read/write secrets.

from __future__ import print_function

import argparse
import base64
import hashlib
import hmac
import json
import os
import sqlite3
import ssl
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

try:
    import configparser
except ImportError:
    import ConfigParser as configparser

VERSION = "0.1.1"

class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

def utc_ts():
    return int(time.time())

def json_bytes(obj):
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8")

def token_hash(token, pepper):
    # Tokens are random 256-bit values. HMAC with a server-only pepper avoids
    # storing reusable bearer tokens in the database.
    return hmac.new(
        pepper.encode("utf-8"),
        token.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()

def load_config(path):
    cp = configparser.ConfigParser()
    if not cp.read(path):
        raise RuntimeError("Konfigurationsdatei nicht gefunden: %s" % path)

    def get(section, key, default=None):
        if cp.has_option(section, key):
            return cp.get(section, key)
        return default

    cfg = {
        "listen_host": get("bridge", "listen_host", "127.0.0.1"),
        "listen_port": int(get("bridge", "listen_port", "8787")),
        "database": get("bridge", "database", "/var/lib/funkgateway-bridge/bridge.sqlite3"),
        "pepper_file": get("bridge", "pepper_file", "/etc/funkgateway-bridge/pepper"),
        "log_file": get("bridge", "audit_log", "/var/log/funkgateway-bridge/audit.log"),
        "tls_cert": get("bridge", "tls_cert", ""),
        "tls_key": get("bridge", "tls_key", ""),
        "ice_host": get("mumble", "ice_host", "127.0.0.1"),
        "ice_port": int(get("mumble", "ice_port", "4000")),
        "slice_file": get("mumble", "slice_file", "/opt/funkgateway-bridge/Murmur.ice"),
        "read_secret_file": get("mumble", "read_secret_file", "/etc/funkgateway-bridge/icesecretread"),
        "write_secret_file": get("mumble", "write_secret_file", "/etc/funkgateway-bridge/icesecretwrite"),
        "encoding": get("mumble", "encoding", "1.0"),
    }
    return cfg

def read_secret_file(path):
    with open(path, "r") as f:
        return f.read().strip()

def ensure_parent(path):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)

def init_db(path):
    ensure_parent(path)
    db = sqlite3.connect(path)
    db.execute("""
        CREATE TABLE IF NOT EXISTS gateways (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            label TEXT NOT NULL,
            mumble_user TEXT NOT NULL,
            normal_channel INTEGER NOT NULL,
            disturbance_channel INTEGER NOT NULL,
            token_hash TEXT NOT NULL UNIQUE,
            enabled INTEGER NOT NULL DEFAULT 1,
            created_at INTEGER NOT NULL
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS gateway_state (
            gateway_id INTEGER PRIMARY KEY,
            previous_channel INTEGER,
            updated_at INTEGER NOT NULL,
            FOREIGN KEY(gateway_id) REFERENCES gateways(id)
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts INTEGER NOT NULL,
            gateway_id INTEGER,
            remote TEXT,
            action TEXT NOT NULL,
            result TEXT NOT NULL,
            detail TEXT
        )
    """)
    db.commit()
    return db

class IceBackend(object):
    def __init__(self, cfg):
        self.cfg = cfg
        self._lock = threading.Lock()
        self._initialized = False
        self._Ice = None
        self._Murmur = None
        self._communicator = None
        self._server = None
        self._read_ctx = None
        self._write_ctx = None

    def initialize(self):
        with self._lock:
            if self._initialized:
                return
            import Ice
            slice_dir = Ice.getSliceDir()
            if not slice_dir:
                raise RuntimeError("Ice Slice-Verzeichnis nicht gefunden")
            Ice.loadSlice('-I"%s" "%s"' % (slice_dir, self.cfg["slice_file"]))
            import Murmur

            props = Ice.createProperties()
            props.setProperty("Ice.Default.EncodingVersion", self.cfg["encoding"])
            init_data = Ice.InitializationData()
            init_data.properties = props
            communicator = Ice.initialize([], init_data)

            base = communicator.stringToProxy(
                "Meta:tcp -h %s -p %d" % (self.cfg["ice_host"], self.cfg["ice_port"])
            )
            meta = Murmur.MetaPrx.checkedCast(base)
            if not meta:
                communicator.destroy()
                raise RuntimeError("Murmur Meta nicht erreichbar")

            read_secret = read_secret_file(self.cfg["read_secret_file"])
            write_secret = read_secret_file(self.cfg["write_secret_file"])
            read_ctx = {"secret": read_secret}
            write_ctx = {"secret": write_secret}

            servers = meta.getAllServers(read_ctx)
            running = [s for s in servers if s.isRunning(read_ctx)]
            if not running:
                communicator.destroy()
                raise RuntimeError("Keine laufende Murmur-Serverinstanz gefunden")

            self._Ice = Ice
            self._Murmur = Murmur
            self._communicator = communicator
            self._server = running[0]
            self._read_ctx = read_ctx
            self._write_ctx = write_ctx
            self._initialized = True

    def status(self):
        self.initialize()
        return {
            "ice": True,
            "server_id": self._server.id(self._read_ctx),
            "running": bool(self._server.isRunning(self._read_ctx))
        }

    def channels(self):
        self.initialize()
        return self._server.getChannels(self._read_ctx)

    def users(self):
        self.initialize()
        return self._server.getUsers(self._read_ctx)

    def find_user(self, name):
        users = self.users()
        matches = [u for u in users.values() if u.name == name]
        if not matches:
            return None
        if len(matches) > 1:
            raise RuntimeError("Mehrere eingeloggte Benutzer mit demselben Namen gefunden")
        return matches[0]

    def get_gateway_state(self, name):
        user = self.find_user(name)
        if user is None:
            return {"online": False, "name": name}
        channels = self.channels()
        ch = channels.get(user.channel)
        return {
            "online": True,
            "name": user.name,
            "session": user.session,
            "channel": user.channel,
            "channel_name": ch.name if ch else None
        }

    def move_gateway(self, gateway_name, allowed_from, target_channel):
        self.initialize()
        user = self.find_user(gateway_name)
        if user is None:
            raise RuntimeError("Gateway-Benutzer ist nicht online")
        if user.channel not in allowed_from:
            raise RuntimeError(
                "Sicherheitsregel: aktueller Channel %s ist nicht freigegeben" % user.channel
            )

        channels = self.channels()
        if target_channel not in channels:
            raise RuntimeError("Ziel-Channel existiert nicht")

        old_channel = user.channel
        user.channel = int(target_channel)
        self._server.setState(user, self._write_ctx)
        return old_channel

class BridgeApp(object):
    def __init__(self, cfg):
        self.cfg = cfg
        self.pepper = read_secret_file(cfg["pepper_file"])
        self.db_lock = threading.Lock()
        self.db = init_db(cfg["database"])
        self.ice = IceBackend(cfg)

    def audit(self, gateway_id, remote, action, result, detail=""):
        with self.db_lock:
            self.db.execute(
                "INSERT INTO audit(ts,gateway_id,remote,action,result,detail) VALUES (?,?,?,?,?,?)",
                (utc_ts(), gateway_id, remote, action, result, detail[:2000])
            )
            self.db.commit()
        try:
            ensure_parent(self.cfg["log_file"])
            with open(self.cfg["log_file"], "a") as f:
                f.write("%d gateway=%s remote=%s action=%s result=%s detail=%s\n" %
                        (utc_ts(), gateway_id, remote, action, result, detail.replace("\n", " ")[:1000]))
        except Exception:
            pass

    def auth(self, header):
        if not header or not header.lower().startswith("bearer "):
            return None
        token = header[7:].strip()
        if not token:
            return None
        th = token_hash(token, self.pepper)
        with self.db_lock:
            row = self.db.execute(
                "SELECT id,label,mumble_user,normal_channel,disturbance_channel,enabled "
                "FROM gateways WHERE token_hash=?",
                (th,)
            ).fetchone()
        if not row or not row[5]:
            return None
        return {
            "id": row[0],
            "label": row[1],
            "mumble_user": row[2],
            "normal_channel": int(row[3]),
            "disturbance_channel": int(row[4]),
        }

    def get_previous(self, gateway_id):
        with self.db_lock:
            row = self.db.execute(
                "SELECT previous_channel FROM gateway_state WHERE gateway_id=?",
                (gateway_id,)
            ).fetchone()
        return None if not row else row[0]

    def set_previous(self, gateway_id, channel):
        with self.db_lock:
            self.db.execute(
                "INSERT OR REPLACE INTO gateway_state(gateway_id,previous_channel,updated_at) "
                "VALUES (?,?,?)",
                (gateway_id, channel, utc_ts())
            )
            self.db.commit()

    def clear_previous(self, gateway_id):
        with self.db_lock:
            self.db.execute("DELETE FROM gateway_state WHERE gateway_id=?", (gateway_id,))
            self.db.commit()

class Handler(BaseHTTPRequestHandler):
    server_version = "FunkGatewayBridge/%s" % VERSION

    def log_message(self, fmt, *args):
        # Avoid leaking Authorization headers or request bodies.
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    @property
    def app(self):
        return self.server.app

    def send_json(self, code, obj):
        body = json_bytes(obj)
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def gateway(self):
        g = self.app.auth(self.headers.get("Authorization"))
        if not g:
            self.send_json(401, {"ok": False, "error": "Token ungültig oder widerrufen"})
            return None
        return g

    def do_GET(self):
        if self.path == "/api/v1/status":
            try:
                st = self.app.ice.status()
                self.send_json(200, {
                    "ok": True,
                    "bridge_version": VERSION,
                    "mumble_ice": st
                })
            except Exception as e:
                self.send_json(503, {"ok": False, "error": str(e)})
            return

        if self.path == "/api/v1/gateway":
            g = self.gateway()
            if not g:
                return
            try:
                st = self.app.ice.get_gateway_state(g["mumble_user"])
                self.send_json(200, {
                    "ok": True,
                    "label": g["label"],
                    "gateway": st,
                    "normal_channel": g["normal_channel"],
                    "disturbance_channel": g["disturbance_channel"]
                })
                self.app.audit(g["id"], self.client_address[0], "gateway.status", "ok")
            except Exception as e:
                self.app.audit(g["id"], self.client_address[0], "gateway.status", "error", str(e))
                self.send_json(500, {"ok": False, "error": str(e)})
            return

        self.send_json(404, {"ok": False, "error": "Nicht gefunden"})

    def do_POST(self):
        g = self.gateway()
        if not g:
            return

        remote = self.client_address[0]
        try:
            if self.path == "/api/v1/gateway/disturbance":
                state = self.app.ice.get_gateway_state(g["mumble_user"])
                if not state.get("online"):
                    raise RuntimeError("Gateway-Benutzer ist nicht online")

                current = int(state["channel"])
                normal = g["normal_channel"]
                disturbance = g["disturbance_channel"]

                if current == disturbance:
                    self.send_json(200, {"ok": True, "changed": False, "channel": disturbance})
                    self.app.audit(g["id"], remote, "gateway.disturbance", "ok", "already there")
                    return

                # Least privilege: only allow transition from configured normal channel.
                if current != normal:
                    raise RuntimeError(
                        "Sicherheitsregel: Wechsel nur vom freigegebenen Normalraum erlaubt"
                    )

                self.app.set_previous(g["id"], current)
                self.app.ice.move_gateway(
                    g["mumble_user"],
                    [normal],
                    disturbance
                )
                self.app.audit(
                    g["id"], remote, "gateway.disturbance", "ok",
                    "%d -> %d" % (current, disturbance)
                )
                self.send_json(200, {"ok": True, "changed": True, "channel": disturbance})
                return

            if self.path == "/api/v1/gateway/return":
                state = self.app.ice.get_gateway_state(g["mumble_user"])
                if not state.get("online"):
                    raise RuntimeError("Gateway-Benutzer ist nicht online")

                current = int(state["channel"])
                normal = g["normal_channel"]
                disturbance = g["disturbance_channel"]

                if current == normal:
                    self.app.clear_previous(g["id"])
                    self.send_json(200, {"ok": True, "changed": False, "channel": normal})
                    self.app.audit(g["id"], remote, "gateway.return", "ok", "already there")
                    return

                if current != disturbance:
                    raise RuntimeError(
                        "Sicherheitsregel: Rückkehr nur aus dem freigegebenen Störungsraum erlaubt"
                    )

                previous = self.app.get_previous(g["id"])
                # v0.1 intentionally returns only to configured normal channel.
                # previous is recorded for audit/recovery but never used to widen permissions.
                target = normal
                self.app.ice.move_gateway(
                    g["mumble_user"],
                    [disturbance],
                    target
                )
                self.app.clear_previous(g["id"])
                self.app.audit(
                    g["id"], remote, "gateway.return", "ok",
                    "%d -> %d (previous=%s)" % (current, target, previous)
                )
                self.send_json(200, {"ok": True, "changed": True, "channel": target})
                return

            self.send_json(404, {"ok": False, "error": "Nicht gefunden"})
        except Exception as e:
            self.app.audit(g["id"], remote, self.path, "error", str(e))
            self.send_json(400, {"ok": False, "error": str(e)})

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="/etc/funkgateway-bridge/bridge.ini")
    args = ap.parse_args()

    cfg = load_config(args.config)
    app = BridgeApp(cfg)

    server = ThreadingHTTPServer((cfg["listen_host"], cfg["listen_port"]), Handler)
    server.app = app

    cert = cfg.get("tls_cert")
    key = cfg.get("tls_key")
    if cert and key:
        server.socket = ssl.wrap_socket(
            server.socket,
            certfile=cert,
            keyfile=key,
            server_side=True,
            ssl_version=ssl.PROTOCOL_TLS
        )

    print("FunkGateway Mumble Bridge %s" % VERSION)
    print("Listen: %s:%d" % (cfg["listen_host"], cfg["listen_port"]))
    if cert and key:
        print("TLS: aktiv")
    else:
        print("TLS: nicht aktiv (empfohlen: nur localhost + HTTPS-Reverse-Proxy)")

    server.serve_forever()

if __name__ == "__main__":
    main()
